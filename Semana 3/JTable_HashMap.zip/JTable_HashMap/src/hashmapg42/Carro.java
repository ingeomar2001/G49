/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package hashmapg42;

/**
 *
 * @author ingeo
 */
class Carro{
    private int codigo;
    private  String marca;
    private  Double valor;
    private  Integer anio;

    public Carro(int codigo, String marca, Double valor, Integer anio) {
        this.codigo = codigo;
        this.marca = marca;
        this.valor = valor;
        this.anio = anio;
    }

    public int getCodigo() {
        return codigo;
    }

    public void setCodigo(int codigo) {
        this.codigo = codigo;
    }   
   

    public String getMarca() {
        return marca;
    }

    public void setMarca(String marca) {
        this.marca = marca;
    }

    public Double getValor() {
        return valor;
    }

    public void setValor(Double valor) {
        this.valor = valor;
    }

    public Integer getAnio() {
        return anio;
    }

    public void setAnio(Integer anio) {
        this.anio = anio;
    }

    @Override
    public String toString() {
        return "Carro{" + "marca=" + marca + ", valor=" + valor + ", anio=" + anio + '}';
    }
    
    
    
}
