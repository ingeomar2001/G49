/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package hashmapg42;

import java.util.HashMap;

/**
 *
 * @author ingeo
 */
public class Datos {
    HashMap<Integer, Carro> carrosMap=new HashMap<Integer, Carro>();

    public Datos() {          
        carrosMap.put(1, new Carro(1,"Ford", 4700.0, 2018));
        carrosMap.put(2, new Carro(2,"Hyundai",3500.0,2015));
        carrosMap.put(3, new Carro(3,"Mercedes", 8500.0, 2015)); 
        carrosMap.put(4, new Carro(4,"Ford", 1500.0, 2021)); 
    }
    
    public void agregarCarro(Carro carro){
        carrosMap.put(carro.getCodigo(), carro);    
    }
    
    public void eliminarCarro(int codigo){
        carrosMap.remove(codigo);
    
    }
    
    public HashMap<Integer, Carro> devolverHashMap(){
        return  carrosMap;
    }
    
    
    
    
}
