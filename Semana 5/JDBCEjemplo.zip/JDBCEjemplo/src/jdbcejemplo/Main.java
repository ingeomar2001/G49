/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package jdbcejemplo;

import java.sql.*;

/**
 *
 * @author ingeo
 */
public class Main {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        String url="jdbc:mysql://localhost:3306/erp?serverTimezone=UTC";
        String user="root";
        String password="admin1234";
        
        try {
            Connection conn= DriverManager.getConnection(url, user, password);
            if (conn != null) {
                System.out.println("Conectado");                
            }
            
            /*Insertar JDBC 
            String sql="INSERT INTO Clientes (Cedula, Nombre, Ciudad, Pais) Values(?,?,?,?)";
            
            PreparedStatement pstm= conn.prepareStatement(sql);
            pstm.setInt(1, 32563);
            pstm.setString(2, "Luis Diaz");
            pstm.setString(3, "Barrancas");
            pstm.setString(4, "Colombia");
            
            int filasAgregadas= pstm.executeUpdate();
            if (filasAgregadas>0) {
                System.out.println("Inserción Exitosa");
                
            }
            */
            
            /* Actualizar 
            
            String sql="UPDATE Clientes SET Ciudad=?, Pais=? WHERE Nombre=?";
            PreparedStatement pstm= conn.prepareStatement(sql);
            pstm.setString(1, "New York");
            pstm.setString(2, "Estados Unidos");
            pstm.setString(3, "Stephen King");
            int filasAgregadas= pstm.executeUpdate();
            if (filasAgregadas>0) {
                System.out.println("Actualización Exitosa");
                
            }
            */
            
            /* Eliminar 
            String sql="DELETE FROM Clientes WHERE Nombre=?";
            PreparedStatement pstm= conn.prepareStatement(sql);
            pstm.setString(1, "Daniel Pardo");
            int filasAgregadas= pstm.executeUpdate();
            if (filasAgregadas>0) {
                System.out.println("Eliminación Exitosa");
                
            }
            */
            
            /*Consultar con Statement
            
            String sql="SELECT * FROM Clientes";
            Statement stm=conn.createStatement();
            ResultSet rs = stm.executeQuery(sql);
            
            while (rs.next()) {
                int cedula=rs.getInt("cedula");
                String nombre=rs.getString("nombre");
                String ciudad=rs.getString("ciudad");
                String pais=rs.getString("pais");
                System.out.println(cedula+","+nombre+","+ciudad+","+pais);               
            }*/
            
            
            

            
            
            
            
            
            
            
            
            
        } catch (SQLException e) {
            e.printStackTrace();
        }
        
        
        
    }
    
}
