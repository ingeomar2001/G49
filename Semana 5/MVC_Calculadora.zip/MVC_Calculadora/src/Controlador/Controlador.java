/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Controlador;

import Modelo.Modelo;
import Vista.Vista;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

/**
 *
 * @author ingeo
 */
public class Controlador implements ActionListener{
    private Vista vista;
    private Modelo modelo;

    public Controlador(Vista vista, Modelo modelo) {
        this.vista = vista;
        this.modelo = modelo;
        this.vista.btnSumar.addActionListener(this);
        this.vista.btnRestar.addActionListener(this);       
    }
    
    public void iniciarVista(){
        vista.setTitle("Calculadora Básica");
        vista.setLocationRelativeTo(null);
        vista.setVisible(true);
    }
    
    
    @Override
    public void actionPerformed(ActionEvent ae) {
        if (ae.getSource()==vista.btnSumar) {
            modelo.setValor1(Integer.parseInt(vista.cmpValor1.getText()));
            modelo.setValor2(Integer.parseInt(vista.cmpValor2.getText()));
            modelo.sumar();
            vista.lblOperacion.setText("+");
            vista.cmpResultado.setText(String.valueOf(modelo.getTotal()));
        
        }
        
    }
    
}
