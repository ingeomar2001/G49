
import java.util.Scanner;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author ingeo
 */
public class Ejercio2 {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        System.out.println("Digite distancia en Kilometros");
        int distancia=sc.nextInt();
        int conMetros=distancia*1000;
        int conCenti=conMetros*100;
        System.out.println("La distancia en Metros es: "+conMetros);
       System.out.println("La distancia en centimetros es: "+conCenti);      
        
    }
    
}
