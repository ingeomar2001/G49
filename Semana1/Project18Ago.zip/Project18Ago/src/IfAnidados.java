
import java.util.Scanner;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author ingeo
 */
public class IfAnidados {
    public static void main(String[] args) {
        Scanner sc=new Scanner(System.in);
        System.out.println("Digite primer número");
        int num1=sc.nextInt();
        System.out.println("Digite segundo número");
        int num2=sc.nextInt();
        if (num1==num2){
            System.out.println("Los números son iguales");            
        } else if (num1>num2) {
            System.out.println("El número "+num1+" es mayor que el número "+num2);
        }else{
            System.out.println("El número "+num2+" es mayor que el número "+num1);            
        }
        
        String cad;
        
        
    }
    
    
}
