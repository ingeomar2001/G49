
import java.util.Scanner;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author ingeo
 */
public class Condicional {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        System.out.println("Digite un saludo: ");
        String cad=sc.nextLine();
        
        if (cad.equals("Hola Mundo")) {
            System.out.println("Hola Usuario");            
        }
        
        
        
    }
    
}
